#!/bin/bash

gcc -std=c99 -Wall -Werror -o ejectuable main.c map.c lista.c manejo_archivos.c filter.c
